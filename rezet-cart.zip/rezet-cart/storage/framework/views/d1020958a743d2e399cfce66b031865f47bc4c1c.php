<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>rezet-cart</title>
	<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
	
<main>
	<?php echo $__env->yieldContent('content'); ?>
</main>

	<script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>
</html><?php /**PATH D:\STEP\PHP\OSPanel\domains\rezet-cart\resources\views/common.blade.php ENDPATH**/ ?>