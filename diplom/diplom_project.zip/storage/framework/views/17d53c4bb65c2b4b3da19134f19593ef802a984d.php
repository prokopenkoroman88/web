


<?php $__env->startSection('title',' все товары категории '); ?>


<?php $__env->startSection('content'); ?>


<h1>
    <p class="capture capt-1" style="width:calc(99% - 0px); display: inline-block;">
        <span>
            <strong>проект <?php echo e($application->product->name ?? '<без проекта>'); ?>

            </strong>
        </span>
    </p>

</h1>

<h2>
	<p class="capture capt-2">
	<span><strong>
		Модуль <?php echo e($application->name); ?>

	</strong></span>
	</p>
</h2>

<div class="container">
	<div class="row">
		<div class="col-md-4">
			<img src="<?php echo e($application->img); ?>" alt="<?php echo e($application->name); ?>">
		</div>
		<div class="col-md-8" id=>
			<?php echo $application->descr; ?>

		</div>		
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.mainpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/admin/applications/show.blade.php ENDPATH**/ ?>