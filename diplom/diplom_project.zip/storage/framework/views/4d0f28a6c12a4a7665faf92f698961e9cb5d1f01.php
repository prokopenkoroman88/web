


<?php $__env->startSection('title',' релиз '); ?>


<?php $__env->startSection('content'); ?>



<h1>
    <p class="capture capt-1" style="width:calc(99% - 103px); display: inline-block;">
        <span>
            <strong>проект <?php echo e($release->product->name ?? '<без проекта>'); ?>

            </strong>
        </span>
    </p>

</h1>

<h2>
	<p class="capture capt-2">
	<span><strong>
		<?php echo e($release->name); ?>

	</strong></span>
	</p>
</h2>

	<article class="container news-snippet">

		<ul class="list">
			<?php $__currentLoopData = $release->applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="cogs"><?php echo e($app->name); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<div class="row">

			<div class="col-md-12 list" id="whats-new-descr">
				<?php echo $release->descr; ?>

			</div>
		</div>
	</article>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.mainpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/admin/releases/show.blade.php ENDPATH**/ ?>