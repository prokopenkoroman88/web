



<?php $__env->startSection('content'); ?>
	##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##




<div id="product-carousel" class="carousel slide" data-ride="carousel">

  <ol class="carousel-indicators">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li data-target="#product-carousel" data-slide-to="<?php echo e($i); ?>" class=" <?php if($i==0): ?>active <?php endif; ?> "></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ol>

  <div class="carousel-inner">

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="carousel-item <?php if($i==0): ?>active <?php endif; ?>">
      <div class="carousel-caption d-none d-md-block"><h2><?php echo e($product->name); ?></h2>
      </div>
      
    <div style="height:200px; overflow: auto;">
      <img src="<?php echo e($product->img); ?>"  alt="<?php echo e($product->name); ?>" class="d-inline w-25" style="float:left; margin: 0px 20px 20px 0px; ">
    
      <div class="d-inline" style="display: inline; "><?php echo $product->descr; ?></div>
	</div>
      <br style="clear: both;">
      <div class="row">
      	<div class="col-md-6">
	      	<h3>Модули</h3>
	      	<ul class="list">
	      		<?php $__currentLoopData = $product->applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<a href="/application/<?php echo e($application->slug); ?>" style="z-index:10;"><?php echo e($application->name); ?></a>
				</li>
	      		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	      	</ul>      		
      	</div>
      	<div class="col-md-6">
       	<h3>Последние обновления</h3>
      	<ul class="list">
      		<?php $__currentLoopData = $product->releases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $release): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><a href="/whatsnew/<?php echo e($product->slug); ?>/<?php echo e($release->version); ?>" style=" position: relative; z-index:11;"><?php echo e($release->version); ?> от <?php echo e($release->date); ?> 
				</a>
			</li>
      		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      	</ul>     		
      	</div>      	
      </div>
   
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>

  <a class="carousel-control-prev" href="#product-carousel" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#product-carousel" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>

</div>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##


    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('user.custompanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/products.blade.php ENDPATH**/ ?>