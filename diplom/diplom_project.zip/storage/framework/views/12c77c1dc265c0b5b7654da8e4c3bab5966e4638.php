



<?php $__env->startSection('content'); ?>
	##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##

<div>
	<p class="red">приложение <?php echo e($application->name); ?></p>

	<div>
		<?php echo $application->describe; ?>

	</div>
</div>


<h2>Задействовано в обновлениях:</h2>
<ul class="list">
<?php $__currentLoopData = $application->releases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $release): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li>
		<a href="/whatsnew/<?php echo e($application->product->slug); ?>/<?php echo e($release->version); ?>"><?php echo e($release->version); ?> от <?php echo e($release->date); ?></a>
	</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('user.custompanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/application.blade.php ENDPATH**/ ?>