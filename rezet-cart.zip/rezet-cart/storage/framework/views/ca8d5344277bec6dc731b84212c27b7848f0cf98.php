


<?php $__env->startSection('content'); ?>
	##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##

<h1>Продукты</h1>

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<article class="snippet product-snippet">
	<p><?php echo e($product->name); ?></p>
	<form action="/cart/add" method="post">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
		<input type="hidden" name="quan" value="1">
		<input type="submit" value="в корзину">
	</form>
</article>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\rezet-cart\resources\views/products.blade.php ENDPATH**/ ?>