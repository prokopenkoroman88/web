


<?php $__env->startSection('content'); ?>
	##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##

<h1>Корзина</h1>


<?php if(!$products): ?>
	<p>В корзине ничего нет</p>
<?php else: ?>

	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<article class="snippet cart-snippet">

		<h2><?php echo e($product['name']); ?></h2>
		<form action="/cart/del" method="post" class="del-form">
			<?php echo e(csrf_field()); ?>

			<input type="hidden" name="product_id" value="<?php echo e($product['id']); ?>">
			<button>
				<img src="images/trash3.png" alt="мусорка" class="trash-img">
			</button>
		</form>


		<img src="/images/<?php echo e($product['img']); ?>" alt="<?php echo e($product['name']); ?>" class="product-img">
		<div class="cart-info">	
<?php
	$descr=\App\Product::find($product['id'])->descr;
?>
		<div class="product-descr">
			<?php echo $descr; ?>

		</div>


	<div class="cart-control">
		<form action="/cart/add" method="post"  class="sub-form">
			<?php echo e(csrf_field()); ?>

			<input type="hidden" name="product_id" value="<?php echo e($product['id']); ?>">
			<input type="hidden" name="quan" value="-1">
			<input type="submit" value="-">
		</form>
		<span class="cart-quan"><?php echo e($product['quan']); ?></span>
		<form action="/cart/add" method="post"  class="add-form">
			<?php echo e(csrf_field()); ?>

			<input type="hidden" name="product_id" value="<?php echo e($product['id']); ?>">
			<input type="hidden" name="quan" value="1">
			<input type="submit" value="+">
		</form>

		<span class="cart-price">
			<?php echo e($product['quan']*$product['price']); ?>&euro;
		</span>
	</div>
	</div>

	</article>


	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<hr>
		
<form action="/shipping" method="POST" class="form-buy">
	<span><?php echo e($totalSum); ?>&euro;</span>
	<?php echo e(csrf_field()); ?> 
	<input type="hidden" name="totalSum" value="<?php echo e($totalSum); ?>">
	<input type="submit" value="BUY">
</form>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\rezet-cart\resources\views/cart.blade.php ENDPATH**/ ?>