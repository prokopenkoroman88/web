


<div class="form-group container">
	
	<div class="row">
		<div class="col-md-3">
			<?php echo Form::label('name', 'Название', ['class' => 'awesome']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::text('name', null, ['class'=>'form-control']); ?>

		</div>
	</div>
	<div class="row">
		<?php if($errors->has('name')): ?>
			<div class="text-danger"><?php echo e($errors->first('name')); ?></div>
		<?php endif; ?>
	</div>


	<div class="row">
		<div class="col-md-3">
			<?php echo Form::label('slug', 'Ярлык', ['class' => 'awesome']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::text('slug', null, ['class'=>'form-control']); ?>

		</div>
	</div>
	<div class="row">
		<?php if($errors->has('slug')): ?>
			<div class="text-danger"><?php echo e($errors->first('slug')); ?></div>
		<?php endif; ?>
	</div>


	<div class="row">
		<div class="col-md-3">
			<?php echo Form::label('sku', 'Артикул', ['class' => 'awesome']); ?>

		</div>		
		<div class="col-md-3">
			<?php echo Form::text('sku', null, ['class'=>'form-control']); ?>	
		</div>
		<div class="col-md-3">
			<?php echo Form::label('price', 'Цена', ['class' => 'awesome']); ?>		
		</div>		
		<div class="col-md-3">
			<?php echo Form::number('price', null, ['class'=>'form-control']); ?>		
		</div>	
	</div>

	<div class="row">
		<div class="col-md-3">
			<?php echo Form::label('descr', 'Описание', ['class' => 'awesome']); ?>

		</div>	
	</div>
	<div class="row">
		<div class="col-12">
			<?php echo Form::textarea('descr', null, ['class'=>'form-control', 'id'=>'descr']); ?>

		</div>
	</div>
</div>




<div class="form-group container">
	<div class="row">
		<div class="col-3" id="preview" style="background-image: url('<?php echo e($product->img); ?>');   ">
			<?php if(!$product->img): ?>
			<?php echo Form::label('img', 'Изображение', ['class' => 'awesome']); ?>	
			<?php endif; ?>
		</div>
		<div class="col-9">

			<?php echo Form::file('img', null, ['class'=>'form-control', 'id'=>'img']); ?>	
 

 		</div>
	</div> 
</div>
 
<div class="form-group container">

	<div class="row">
		<div class="offset-md-9 col-md-3">
<?php echo Form::submit('Save', ['class'=>'form-control btn btn-primary d-inline-block']);; ?>			
		</div>
	</div>

</div>


<script>
/*
	let preview=document.getElementById('preview');
	let imgInput=document.getElementById('img');
	imgInput.addEventListener('change', function(){
		//
		//alert(imgInput.value);
		preview.style.background = 'url('+imgInput.value+')';


	});
*/

</script>
<?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/admin/products/form.blade.php ENDPATH**/ ?>