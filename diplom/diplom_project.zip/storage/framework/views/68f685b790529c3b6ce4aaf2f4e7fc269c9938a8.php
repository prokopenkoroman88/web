


	
<span class="redact-panel">		
	<?php if(!isset($item)): ?>
<?php
		$params='';
		if(isset($product)){
			$params.=($params?'&':'?').'product_id='.$product->id;
		};
		
?>
			<a href="<?php echo e($path); ?>/create<?php echo e($params); ?>" class="redact-btn redact-new">*</a>


	<?php else: ?>
			<form action="<?php echo e($path); ?>/<?php echo e($item->id); ?>/edit" method="GET">
				<button type="submit" class="redact-btn redact-edit">
					<i class="far fa-edit"></i>
				</button>
			</form>

			<form action="<?php echo e($path); ?>/<?php echo e($item->id); ?>" method="POST">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="_method" value="DELETE">
				<button type="submit" class="redact-btn redact-del">
					<i class="far fa-trash-alt"></i>
				</button>

				<!--input type="submit" value="Del"-->
				
			</form>

			<a href="<?php echo e($path); ?>/<?php echo e($item->id); ?>/"  class="redact-btn redact-show"><i class="far fa-eye"></i></a>





	<?php endif; ?>

</span>
<?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/layouts/redact.blade.php ENDPATH**/ ?>