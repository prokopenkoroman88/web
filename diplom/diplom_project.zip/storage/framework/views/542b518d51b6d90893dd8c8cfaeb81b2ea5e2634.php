
<div class="content site-map">

<?php
	$latest = App\Product::all();

?>
<div>
<ul class="list">
 <li class="folder folder-opened"><span></span>Карта сайта

    <ul>
    	<li class="page"><span></span><a href="/">Последние новости</a>
    	</li>
	    <li class="folder folder-opened"><span></span><a href="/products">Проекты</a>
	        <ul >            
	            <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                <li class="folder folder-closed"><span></span><a href="/product/<?php echo e($p->slug); ?>"><?php echo e($p->name); ?></a>

						<ul>
							<?php
$pReleases = App\Release::where('product_id','=',$p->id)->get();
							?>
							<?php $__currentLoopData = $pReleases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pRelease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="page"><span></span><a href="/whatsnew/<?php echo e($p->slug); ?>/<?php echo e($pRelease->version); ?>"><?php echo e($pRelease->version); ?></a></li>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
	                </li>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        </ul>
	    </li>
	    <li class="folder folder-closed"><span></span>
	    	<a href="/contacts">Контакты</a>
	    	<ul>
				<li class="page"><span></span>
					<a href="/contacts#schedule">Режим работы</a>
				</li>
				<li class="page"><span></span>
					<a href="/contacts#question">Написать разработчику</a>
				</li>		
	    	</ul>
	    </li>
	        
	</ul>
 </li>
</ul>
</div>

<?php
$lastRelease = App\Release::where('created_at','<>','0')->orderBy('created_at','DESC')->first();
?>



	<h4 itemscope itemtype="http://schema.org/CreativeWork" style="font-size: 1em;">
		<p class="capture capt-0">
			<span>
				<strong style="font-weight:normal; background-color:#eeeeee;" 
				itemprop="datePublished" content="<?php echo e($lastRelease->creatingDate); ?>">
				Последнее обновление сайта - <?php echo e($lastRelease->creatingDateHuman); ?>

				</strong>
			</span>
		</p>
	</h4>


</div>

<?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/layouts/map.blade.php ENDPATH**/ ?>