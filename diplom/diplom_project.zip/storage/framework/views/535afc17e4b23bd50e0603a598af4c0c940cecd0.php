


<?php $__env->startSection('title',' все релизы '); ?>

<?php $__env->startSection('content'); ?>


<?php echo e(view('admin.releases._list',compact('releases'))); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
	<script>
		//$('table').DataTable()//+10.3.20 плагин 



	</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.mainpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/admin/releases/index.blade.php ENDPATH**/ ?>