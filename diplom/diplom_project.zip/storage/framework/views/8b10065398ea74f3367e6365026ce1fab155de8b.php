

<?php if(Auth::user()): ?>

<?php

$products = App\Product::where('name','<>','""')->orderBy('name','ASC')->pluck('name','id')->all();

?>




<?php echo Form::model(null,['url'=>'/question', 'enctype'=>'multipart/form-data','style'=>'width:100%;', 'method'=>'post' ]); ?>



			<?php if(session('message')): ?>
				<h1 class="text-<?php echo e(session('message')['class']); ?>">
					<?php echo e(session('message')['text']); ?>					
				</h1>
				<? Session::forget('message'); ?>
			<?php endif; ?>


<div class="form-group container">
	<div class="row">
		<div class="col-md-12">

			<?php echo Form::select('product_id', 
				$products,//['L' => 'Large', 'S' => 'Small'], 
				null, //выделенный элемент
				['placeholder' => 'Выберите продукт', 'class'=>'form-control select'] //доп парам
			); ?>	
					
		</div>

	</div>

</div>





<div class="form-group container">

	<div class="row">		
		<div class="col-md-12">
			<?php echo Form::textarea('descr', null, ['class'=>'form-control', 'id'	=>'descr', 'placeholder'=>'Что Вас интересует?']); ?>

		</div>
	</div>
</div>

<div class="form-group container">
	<div class="row">
		<div class="offset-md-8 col-md-4">
<?php echo Form::submit('Отправить', ['class'=>'form-control btn btn-primary d-inline-block']);; ?>			
		</div>
	</div>	
</div>


<?php echo Form::close(); ?>


<?php else: ?>

<p class="red">Написать разработчику могут только зарегистрированные пользователи</p>

<?php endif; ?>
<?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/user/comments/question.blade.php ENDPATH**/ ?>