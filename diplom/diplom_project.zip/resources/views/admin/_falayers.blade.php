{{-- 
  @include('admin._falayers') 
--}}

<div class="fa-4x">
  <span class="fa-layers fa-fw" style="background:MistyRose">
    <i class="fas fa-circle" style="color:Tomato"></i>
    <i class="fa-inverse fas fa-times" data-fa-transform="shrink-6"></i>
  </span>
*
  <span class="fa-layers fa-fw" style="background:MistyRose">
    <i class="fas fa-bookmark" style="top:0px; left:0px; "></i>
    <i class="fa-inverse fas fa-heart" data-fa-transform="shrink-10 up-2" style="color:Tomato; top:3px; left:3px; font-size:0.5em; "></i>
  </span>
*
  <span class="fa-layers fa-fw" style="background:MistyRose">
    <i class="fas fa-play" data-fa-transform="rotate--90 grow-2" style="top:0px; left:0px; transform:rotate(-90deg); "></i>
    <i class="fas fa-sun fa-inverse" data-fa-transform="shrink-10 up-2" style="top:5px; left:20px; font-size:0.25em;  "></i>
    <i class="fas fa-moon fa-inverse" data-fa-transform="shrink-11 down-4.2 left-4" style="top:35px; left:5px; font-size:0.25em;  "></i>
    <i class="fas fa-star fa-inverse" data-fa-transform="shrink-11 down-4.2 right-4" style="top:35px; left:30px; font-size:0.25em;  "></i>
  </span>
*
  <span class="fa-layers fa-fw" style="background:MistyRose">
    <i class="fas fa-calendar"></i>
    <span class="fa-layers-text fa-inverse" data-fa-transform="shrink-8 down-3" style="font-weight:900">27</span>
  </span>
*
  <span class="fa-layers fa-fw" style="background:MistyRose">
    <i class="fas fa-certificate"></i>
    <span class="fa-layers-text fa-inverse" data-fa-transform="shrink-11.5 rotate--30" style="font-weight:900">NEW</span>
  </span>

  <span class="fa-layers fa-fw" style="background:MistyRose">
    <i class="fas fa-envelope"></i>
    <span class="fa-layers-counter" style="background:Tomato">1,419</span>
  </span>
</div>
