


<?php $__env->startSection('content'); ?>
	##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##

<h1>Доставка</h1>


<form action="/shipping/pay" method="POST" class="shipping-form" name="shipping">
	<?php echo e(csrf_field()); ?>


	<label>
		<span>Name*</span>
		<input type="text" name="name">
		<div class="text-danger none"></div>
	</label>

	
	<label>
		<span>Address*</span>
		<input type="text" name="address">
		<div class="text-danger none"></div>
	</label>

	
	<label>
		<span>Phone</span>
		<input type="tel" name="phone">
		<div class="text-danger none"></div>
	</label>
	<label>
		<span>E-mail</span>
		<input type="e-mail" name="email">
		<div class="text-danger none"></div>
	</label>

	<label>
		<span>Shipping options</span>
		<select name="options"  >
<?php

$aShp=[
	 ['value'=>'Free shipping','inner'=>'Free shipping','from'=>0,'less'=>10]
	,['value'=>'Express shipping','inner'=>'Express shipping','from'=>10,'less'=>20]
	,['value'=>'Courier shipping','inner'=>'Courier shipping','from'=>20,'less'=>300]
	,['value'=>'Free express shipping','inner'=>'Free express shipping','from'=>300,'less'=>0]
];

$totalSum=$_POST['totalSum'];

?>
			<?php $__currentLoopData = $aShp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $shp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($shp['value']); ?>" 
				<?php if($shp['from']<=$totalSum && (!$shp['less'] || $totalSum<$shp['less'])): ?>selected
				<?php endif; ?>
				><?php echo e($shp['inner']); ?></option>


			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
		</select>
	</label>

	<input type="submit" value="PAY" name="pay" disabled>


</form>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\rezet-cart\resources\views/shipping.blade.php ENDPATH**/ ?>