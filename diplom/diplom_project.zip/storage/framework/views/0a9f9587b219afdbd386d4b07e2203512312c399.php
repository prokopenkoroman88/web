
<?php
//$href $item['url']
//$text $item['table']
//$count $item['label']

	$url = $_SERVER['REQUEST_URI']; // "/admin/releases"

	//$active = ($url==$href)?'active':'';
	$active = (strpos($url,$href)!==false)?'active':'';

	$has_count = (isset($count))?'has-count':'';

?>
	<li class="nav-item <?php echo e($active); ?> <?php echo e($has_count); ?> nowrap">
		<a href="<?php echo e($href); ?>" class="nav-link ">
			<span class="link-text"><?php echo $text; ?></span>
		</a>
	<?php if(isset($count)): ?>
		<span class="elem-count"><?php echo e($count); ?></span>
	<?php endif; ?>
	</li>

<?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/layouts/li.blade.php ENDPATH**/ ?>