





<?php $__env->startSection('header'); ?>



<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
	


	<h1 itemscope itemtype="http://schema.org/CreativeWork" style="font-size: 1em;">
		<p class="capture capt-product" itemprop="name"><strong><?php echo e($product->name); ?></strong></p>
		<p class="capture capt-1-news">
			<span>
				<strong>Что нового</strong>
			</span>
		</p>
		<p class="capture capt-version">
		<span></span><span></span>
		<b itemprop="datePublished" content="<?php echo e($release->date); ?>"><?php echo e($release->date); ?></b>
		Версия <?php echo e($release->version); ?>

		</p>
	</h1>

<aside>
	<h4><?php if($release->isDistr()): ?> Дистрибутив <?php else: ?> Обновление <?php endif; ?> включает:</h4>
	<p class="fat">
	Версия серверной части <?php echo e($release->server_version); ?><br>
	Версия клиентской части <?php echo e($release->client_version); ?>

	</p>
	<hr class=rc2>
</aside>



<div id="whats-new-descr" class="list">
	<?php echo $release->descr; ?>

</div>

<aside>
	<hr class=rc2>
	<h4>Порядок установки:</h4>
<?php if($release->last): ?>
	<p class="fat">Обновление можно устанавливать на версию не ниже <?php echo e($release->last->version); ?></p>
<?php endif; ?>
	<ul>
		<li>Создать резервные копии ВСЕХ БАЗ ДАННЫХ.</li>
		<li>Запустить на выполнение файл <?php echo e(App\Services\Statistic::the_fileShortName($release->files)); ?> 
			
		.</li>
		<li>Открыть базу данных.</li>
	</ul>	
</aside>


<?php
//dd($release->last->version  );
?>


<p>средняя оценка: <?php echo e(round($release->mark,1)); ?>

<?php echo e($release->get_starmark()); ?></p>


<?php if(auth()->guard()->guest()): ?>
<p class="text-danger">Зарегистрируйтесь, чтобы оставить отзыв</p>
<?php else: ?>
<div class="form-group container">
	<div class="row">
		<div class="col-md-12">

<h2 id="new-comment"></h2>
<?php
$comment= new App\Comment();
$comment->user_id = Auth::user()->id;
$comment->release_id = $release->id;

?>

	<?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo Form::model($comment,['url'=>'/user/comments' ]); ?>

	<?php echo $__env->make('user.comments.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo Form::close(); ?>


		</div>
	</div>
</div>
<?php endif; ?>


<h2>Все Отзывы:</h2>
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<article class="container comment">

	<div class="row">
		<div class="col-md-3">
			<h3><?php echo e($comment->user->name); ?></h3>
			<p><?php echo e($comment->get_starmark()); ?></p>
			
			<p><?php echo e($comment->mark); ?></p>

			<p class="time"><?php echo e($comment->created_at); ?></p>
		</div>
		<div class="col-md-9">
			<div class="comment-text"><?php echo $comment->descr; ?></div>
			
		</div>
	</div>

</article>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
	<?php echo $__env->make('layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.custompanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/whatsnew.blade.php ENDPATH**/ ?>