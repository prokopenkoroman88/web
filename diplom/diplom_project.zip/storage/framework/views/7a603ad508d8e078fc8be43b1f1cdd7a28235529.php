




<?php $__env->startSection('content'); ?>
	##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##

<h4>
    <p class="capture capt-1" style="width:calc(99% - 103px); display: inline-block;">
        <span>
            <strong>проект <?php echo e($product->name); ?>

            </strong>
        </span>
    </p>

    <p style="font-size: 10px; display: inline-block; width:103px; ">
        <?php echo e($product->get_starmark()); ?>

    </p>
</h4>


<h5>
	<p class="capture capt-2">
	<span><strong>
		<?php if($product->last()): ?>
			последняя версия: 
			<?php echo e($product->last()->version); ?>

		<?php else: ?>
			нет ниодной версии
		<?php endif; ?>	
	</strong></span>
	</p>
</h5>



<div class="descr ">
	<div></div>
	<div></div>

	<span>

 
	<?php echo $product->descr; ?>


</span>

 
<span class="descr-bottom">
	<div></div>
	<div></div>
	<span>



	</span>
</span>	

</div>



<h2>его релизы:</h2>

<table class="product-table">
	<tr>
		<th>Дата</th>
		<th>Скачать файл</th>
		<th>Версия</th>
		<th>Размер, кБ</th>
		<th>Инструкция</th>
		<th></th>
	</tr>
<?php $__currentLoopData = $releases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $release): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td>
			<?php echo e($release->date); ?>

		</td>
		<td>


			<ul>
			<?php $__currentLoopData = explode("\n",$release->files); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><a href="<?php echo e($file); ?>" download><?php echo e(App\Services\Statistic::the_fileShortName($file)); ?> 
				</a></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>

		</td>
		<td>
			<?php echo e($release->version); ?>

		</td>
		<td>
			<ul>
			<?php $__currentLoopData = explode("\n",$release->files); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<?php echo e(App\Services\Statistic::the_filesize($file,'КБ')); ?>

				<?php
				//echo round((filesize($file)/1024),1).' КБ' 
				?>
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</td>
		<td>

			<a href="/whatsnew/<?php echo e($product->slug); ?>/<?php echo e($release->version); ?>">Прочитать</a>

		</td>
		<td>
			<span style="font-size: 10px;">
                                    <?php echo e($release->get_starmark()); ?></span>
		</td>

	</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.custompanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/product.blade.php ENDPATH**/ ?>