


<?php
use App\Http\Controllers\Admin\AdminController;

?>

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('nav'); ?> 
<?php
$classes = AdminController::classes();

//dd($classes);

$url = $_SERVER['REQUEST_URI']; // "/admin/releases"

?>


<?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
	$href= $item['url'];
	$text= $item['table'];
	$count= $item['label'];
	echo view('layouts.li',compact('href','text','count'));
?>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?> 

	<h1 itemscope style="font-size: 1em;">
		<p class="capture capt-0">
			<span >
				<strong style="background-color:#eeeeee;">
					Администрационная панель
				</strong>
			</span>
		</p>
	</h1>


<a href="/admin/init">Инициализировать базу</a>





<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/admin/mainpanel.blade.php ENDPATH**/ ?>