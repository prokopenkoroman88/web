


<?php $__env->startSection('title',' все товары '); ?>

<?php $__env->startSection('content'); ?>
	

<?php echo e(view('admin.products._list',compact('products'))); ?>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
	<script>
		//?//$('table').DataTable();//+10.3.20 плагин 
	</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.mainpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/admin/products/index.blade.php ENDPATH**/ ?>