<h1>Уважаемый(ая) <?php echo e($dest->name); ?>!</h1>

<?php if(isset($product)): ?>
<p class="red">Замечание по проекту <b><?php echo e($product->name); ?></b></p>
<?php endif; ?>

<div>
	<?php echo $descr; ?>

</div>
<p>С уважением <?php echo e($send->name); ?>.</p>
<?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/user/comments/mail.blade.php ENDPATH**/ ?>