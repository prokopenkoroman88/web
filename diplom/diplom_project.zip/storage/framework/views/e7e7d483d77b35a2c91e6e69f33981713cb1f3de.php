<?php $__env->startSection('content'); ?>

<div class="content">

<?php
$product_id=0;
?>


    <?php $__currentLoopData = $latest_releases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $release): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($release->product_id!=$product_id): ?>
            <?php if($product_id): ?>
                </table>
                </article>
            <?php endif; ?>

            <article class="updates">

                <h4>
                    <p class="capture capt-2" style="width:calc(99% - 103px); display: inline-block;">
                        <span>
                            <strong>Последние новости проекта <a href="/product/<?php echo e($release->product->slug); ?>"><?php echo e($release->product->name); ?></a>
                            
                                                
                            
                            </strong>
                        </span>
                    </p>

                    <p style="font-size: 10px; display: inline-block; width:103px; ">
                        <?php echo e($release->product->get_starmark()); ?>

                    </p>
                </h4>
                <table class="new-releases">


    <?php
            $product_id=$release->product_id;
    ?>
        <?php endif; ?>



                <tr>            
                    <td>
                        <?php echo $release->date; ?>

                    </td>
                    <td>
                        <?php if($release->isDistr()): ?>
                            Доступен для скачивания дистрибутив
                        <?php else: ?>
                            Выход новой версии
                        <?php endif; ?>
                            программы <?php echo e($release->name); ?>

                    </td>
                    <td>
                        <a href="/product/<?php echo e($release->product->slug ?? ''); ?>/#year<?php echo e($release->year); ?>">Обновления</a>
                    </td>

                </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($product_id): ?>
                </table>
                </article>
            <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('user.custompanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/home.blade.php ENDPATH**/ ?>