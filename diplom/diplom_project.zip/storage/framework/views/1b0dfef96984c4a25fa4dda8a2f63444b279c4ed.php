



<?php $__env->startSection('nav'); ?>
<?php

$url = $_SERVER['REQUEST_URI']; // "/products"



?>

<?php
	$href= '/products';
	$text= 'Проекты';
	echo view('layouts.li',compact('href','text'));

	$href= '/contacts';
	$text= 'Контакты';
	echo view('layouts.li',compact('href','text'));	

	if(Auth::user()){
		$href= '/contacts#question';
		$text= "Написать<br>разработчику";
		echo view('layouts.li',compact('href','text'));			
	}
	
?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('left_panel'); ?>
    <?php echo $__env->make('layouts.map', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>





<?php $__env->startSection('right_panel'); ?>
    
<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>
	<p>© 2020</p>

    <a href="/contacts#question">написать разработчику</a>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/user/custompanel.blade.php ENDPATH**/ ?>