

<?php
//*
	if(isset($_GET['product_id'])){
		//
		$product=App\Product::find($_GET['product_id']);

	};
//*/
	if(!isset($product)){
		$product=$release->product;
	}
	else
	if(!$release->product_id){
		$release->product_id=$product->id;
	};


	if(!isset($products)){

		$products = App\Product::where('name','<>','""')->orderBy('name','ASC')->pluck('name','id')->all();		
	};


	//'name' -> 'version'  ->all('id','version')
	$releases = App\Release::where('product_id','=',$product->id ?? 0)->orderBy('version','ASC')->pluck('version','id')->all();
	//all();
	//all('id','name')->pluck('name','id')->all();
	//$applications = App\Application::all('id','name')->orderBy('name','DESC')->pluck('name','id')->all();

	$applications = App\Application::where('product_id','=',$product->id)->orderBy('name','ASC')->pluck('name','id')->all();


	if(!$release->date)
		$release->date=date('Y-m-d');
	//'2020-04-03'
?>
<span><?php echo e($product->id); ?></span>




<div class="form-group container">
	<div class="row">
		<div class="col-md-2">
			<?php echo Form::label('product_id', 'Продукт', ['class' => 'awesome']); ?>			
		</div>
		<div class="col-md-10">

			<?php echo Form::select('product_id', 
				$products,//['L' => 'Large', 'S' => 'Small'], 
				null, //выделенный элемент
				['placeholder' => 'Выберите продукт', 'class'=>'form-control select'] //доп парам
			); ?>	
					
		</div>

	</div>
	<div class="row">
		<div class="col-md-12">	

			<?php if($errors->has('product_id')): ?>
				<div class="text-danger"><?php echo e($errors->first('product_id')); ?></div>
			<?php endif; ?>

		</div>
	</div>
</div>




<div class="form-group container">

	<div class="row">
		<div class="col-md-2">	
			<?php echo Form::label('name', 'Название', ['class' => 'awesome']); ?>

		</div>
		<div class="col-md-10">				
			<?php echo Form::text('name', null, ['class'=>'form-control']); ?>


	<input type="text" name="slug" value="<?php echo e($release->slug); ?>" readonly>

		</div>
	</div>


	<div class="row">
		<div class="offset-md-2 col-md-10">	
	<?php if($errors->has('name')): ?>
		<div class="text-danger"><?php echo e($errors->first('name')); ?></div>
	<?php endif; ?>
		</div>
	</div>

</div>



<div class="form-group container">

	<div class="row">
		<div class="col-md-6">

			<div class="row">
				<div class="col-md-12">
					<label for="">Версии в обновлении:</label>
				</div>
			</div>

			<div class="row">
				<div class="col-4">
					<?php echo Form::label('version', 'релиза', ['class' => 'awesome']); ?>

				</div>
				<div class="col-8">
					<?php echo Form::text('version', null, ['class'=>'form-control']); ?>

				</div>				
			</div>

			<div class="row">
				<div class="col-4">
					<?php echo Form::label('server_version', 'сервера', ['class' => 'awesome']); ?>

				</div>
				<div class="col-8">
					<?php echo Form::text('server_version', null, ['class'=>'form-control']); ?>

				</div>				
			</div>

			<div class="row">
				<div class="col-4">
					<?php echo Form::label('client_version', 'клиента', ['class' => 'awesome']); ?>

				</div>
				<div class="col-8">
					<?php echo Form::text('client_version', null, ['class'=>'form-control']); ?>

				</div>				
			</div>

			<div class="row">
				<div class="col-4">
					<?php echo Form::label('last_id', 'Ставить на', ['class' => 'awesome nowrap']); ?>

				</div>
				<div class="col-8">
					<?php echo Form::select('last_id', 
				$releases,//['L' => 'Large', 'S' => 'Small'], 
				null, //выделенный элемент
				['placeholder' => 'Select last', 'class'=>'form-control select'] //доп парам
			); ?>

				</div>				
			</div>

			<div class="row">
				<div class="col-4">
					<?php echo Form::label('included_id', 'Включено в', ['class' => 'awesome nowrap']); ?>

				</div>
				<div class="col-8">
					<?php echo Form::select('included_id', 
				$releases,//['L' => 'Large', 'S' => 'Small'], 
				null, //выделенный элемент
				['placeholder' => 'Select included', 'class'=>'form-control select'] //доп парам
			); ?>

				</div>				
			</div>
			
			<hr>
			
			<div class="row">
				<div class="col-4">
					<?php echo Form::label('date', 'Дата релиза', ['class' => 'awesome']); ?>

				</div>
				<div class="col-8">
					<?php echo Form::date('date', null, ['class'=>'form-control']); ?>

			<?php if($errors->has('date')): ?>
				<div class="text-danger"><?php echo e($errors->first('date')); ?></div>
			<?php endif; ?>
				</div>				
			</div>

			<div class="row">
				<div class="col-4">
					<?php echo Form::label('price', 'Цена', ['class' => 'awesome']); ?>

				</div>
				<div class="col-8">
					<?php echo Form::number('price', null, ['class'=>'form-control']); ?>

				</div>				
			</div>	


		</div>
		<div class="col-md-6">

			<div class="row">
				<div class="col-md-12">
					<?php echo Form::label('applications[]', 'Компоненты обновления:', ['class' => 'awesome']); ?>

				</div>
			</div>
			<div class="row">
				<div class="col-md-12">

			<?php echo Form::select('applications[]', 
				$applications,//['L' => 'Large', 'S' => 'Small'], 
				null, //выделенный элемент
				//'placeholder' => 'Select components',
				[ 'multiple'=>'multiple', 'class'=>'form-control select', 'id'=>'select-applications'] //доп парам
			); ?>		

				</div>
			</div>


		</div>		
	</div>
</div>







<div class="form-group container">

	<div class="row">
		<div class="col-md-2">	
	<?php echo Form::label('descr', 'Что нового', ['class' => 'awesome']); ?>

		</div>

	</div>

	<div class="row">
		<div class="col-md-12">	
	<?php echo Form::textarea('descr', null, ['class'=>'form-control', 'id'=>'descr']); ?>

		</div>
	</div>
</div>





<div class="form-group container">
	<div class="row">
		<div class="col-12">
			<h3>Загруженные файлы обновления</h3>
			<ul>
			<?php $__currentLoopData = explode("\n",$release->files); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><a href="<?php echo e($file); ?>"><?php echo e($file); ?> 
					<?php echo e(App\Services\Statistic::the_filesize($file,'КБ')); ?>

				<?php
				//echo round((filesize($file)/1024),1).' КБ' ?>
				</a></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>

	<div class="row">
		<div class="col-12">
			<input type="file" name="files[]" id="files" multiple>

		</div>
	</div> 
</div>


 
<div class="form-group container">

	<div class="row">
		<div class="offset-md-9 col-md-3">
<?php echo Form::submit('Save', ['class'=>'form-control btn btn-primary d-inline-block']);; ?>			
		</div>
	</div>

</div>


<?php $__env->startSection('js'); ?>
	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
	<?php echo $__env->make('layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>


setTimeout(afterload, 1000);

function afterload(){
//-28.4.20//var spanTmp = document.getElementById('span_template');
var fr=document.querySelector('iframe');
var frcd=fr.contentDocument || fr.contentWindow.document;//
var bd=frcd.querySelector('body');
/*-28.4.20
spanTmp.addEventListener('click',function(event){

	console.log(bd.childNodes);

	let sVer=document.getElementById('version').value;
	let sVer2=document.getElementById('server_version').value;
	let sVer3=document.getElementById('client_version').value;

	//bd.innerHTML += ('<b> <i>'+sVer+'</i> '+sVer2+'</b> '+sVer3);




});
*/
var selApps=document.getElementById('select-applications');
var opts=document.querySelectorAll('#select-applications option');
for(let i=0;i<opts.length;i++){
	opts[i].addEventListener('click', function(e){
		//this.innerHTML
		console.log(e);
		let s=e.toElement.text;

		if(e.toElement.selected){
			let node = frcd.createElement('article');
			//node.style.background = 'pink';
			node.innerHTML='<h4>'+s+'</h4><ul><li></li></ul>';
			bd.append(node);
		}
		else{
			let nodes=frcd.querySelectorAll('article');
			for(let i=0;i<nodes.length;i++){
				if(nodes[i].querySelector('h4').innerHTML == s)
					nodes[i].remove();//удалит найдя по названию заголовка
			};
		};


	});//f
		
};//i++



};


</script>

<?php $__env->stopSection(); ?>

<?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/admin/releases/form.blade.php ENDPATH**/ ?>