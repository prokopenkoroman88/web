



<?php $__env->startSection('title',' Продукт '); ?>


<?php $__env->startSection('css'); ?>
	##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<style>
#preview{
	background-image: url('<?php echo e($product->img); ?>');
}
</style>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>




<h1 class="text-center">Продукт <?php echo e($product->name); ?></h1>
	<div class="container">
		
		<div class="row">
			<div class="col-md-4" id="preview" style="background-image: url('<?php echo e($product->img); ?>');   ">
			</div>
			<div class="col-md-8">
				<p>Артикул <?php echo e($product->sku); ?> Цена <?php echo e($product->price); ?></p>
				<div><?php echo $product->descr; ?>

					
				</div>
			</div>
		</div>
	</div>


<h6 class="tabs-panel">
	<span class="tab-selected">Релизы</span>
	<span class="">Приложения</span>
</h6>
<div class="tabs-body"> 

	<article>
		<?php echo e(view('admin.releases._list',compact('releases','product'))); ?>

	</article>

	<article style="display:none;">
		<?php echo e(view('admin.applications._list',compact('applications','product'))); ?>

	</article>

</div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
	<?php echo $__env->make('layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    

<script>

$(document).ready( function () {
	//.admin-table //.tabs-body table//#myTable
	//alert('ready');

	console.log($('#applications-table'));
	console.log(document.getElementById('applications-table'));

	console.log($('#applications-table').DataTable);


    //$('#applications-table').DataTable();//
} );

var tabsBody=document.querySelectorAll('.tabs-body article');


var tabsPanel=document.querySelectorAll('.tabs-panel span');

for (var i = tabsPanel.length - 1; i >= 0; i--){
	tabsPanel[i].addEventListener('click',function(){
		//console.log(tabsPanel);//?	

		let ii=-1;
		for(let j=0;j<tabsPanel.length;j++){
			if(tabsPanel[j]==this)
				ii=j;
			if(tabsPanel[j].classList.contains('tab-selected'))
				tabsPanel[j].classList.remove('tab-selected');
			if(tabsBody[j])
				tabsBody[j].style.display = 'none';
		};

		console.log(ii);//tabsPanel.indexOf(this)
		//let ii=tabsPanel.indexOf(this);

		this.classList.add('tab-selected');
		if(tabsBody[ii])
			tabsBody[ii].style.display = 'block';
	});
};

let search = location.search;
let tab = (search.split('&')[0]).split('=')[1]
if(tab){

	tabsPanel[tab].click()
}

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.mainpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/admin/products/show.blade.php ENDPATH**/ ?>