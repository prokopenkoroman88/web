








<table class="admin-table">
	<tr>
		<th>#</th>
		<th>Name</th>
		<th></th>
		<th>Модули</th>
		<th>Релизы</th>
	</tr>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<tr>
		<td><?php echo e($loop->iteration); ?></td>
		<td><strong><?php echo e($item->name); ?></strong></td>
		<td>

<?php
//$path='admin/products'; 

$ac= new \App\Http\Controllers\Admin\ProductController();
$path= $ac->path;
?>
<?php echo e(view('layouts.redact',compact('path','item'))); ?>

		</td>

<?php
	$product=$item;//?
?>
		<td class="has-count">
			<span class="elem-count"><?php echo e($product->applications->count()); ?></span>

<?php

$ac= new \App\Http\Controllers\Admin\ApplicationController();
$path= $ac->path;
// '/admin/applications'; 
?>
<?php echo e(view('layouts.redact',compact('path','product'))); ?>


		</td>
		<td class="has-count">
			<span class="elem-count"><?php echo e($product->releases->count()); ?></span>

<?php

$ac= new \App\Http\Controllers\Admin\ReleaseController();
$path= $ac->path;
// '/admin/applications'; 
?>
<?php echo e(view('layouts.redact',compact('path','product'))); ?>


		</td>
	</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<?php
//$path='admin/products'; 

$ac= new \App\Http\Controllers\Admin\ProductController();
$path= $ac->path;
?>

<p>
<?php echo e(view('layouts.redact',compact('path'))); ?>


</p>







<?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/admin/products/_list.blade.php ENDPATH**/ ?>