


<?php $__env->startSection('title', 'Add product'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Add product</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	

	<?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo Form::model($product,['url'=>'/admin/products', 'enctype'=>'multipart/form-data' ]); ?>

	<?php echo $__env->make('admin.products.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<?php echo $__env->make('layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.mainpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/admin/products/create.blade.php ENDPATH**/ ?>