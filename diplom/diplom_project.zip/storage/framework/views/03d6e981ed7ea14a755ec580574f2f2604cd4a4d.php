


<div class="form-group">
	<?php echo Form::label('name', 'Product name:', ['class' => 'awesome']); ?>

	<?php echo Form::text('name', null, ['class'=>'form-control']); ?>


	<?php if($errors->has('name')): ?>
		<div class="text-danger"><?php echo e($errors->first('name')); ?></div>
	<?php endif; ?>

</div>


<div class="form-group">
	<?php echo Form::label('applications[]', 'Product Category:', ['class' => 'awesome']); ?>

	<?php echo Form::select('applications[]', 
		$applications,//['L' => 'Large', 'S' => 'Small'], 
		null, //выделенный элемент
		['placeholder' => 'Select parent category', 'multiple'=>'multiple', 'class'=>'form-control select'] //доп парам
	); ?>

</div> 



<div class="form-group">
	<?php echo Form::label('slug', 'Product slug:', ['class' => 'awesome']); ?>

	<?php echo Form::text('slug', null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
	<?php echo Form::label('price', 'Product price:', ['class' => 'awesome']); ?>

	<?php echo Form::number('price', null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
	<?php echo Form::label('describe', 'Product describe:', ['class' => 'awesome']); ?>

	<?php echo Form::textarea('describe', null, ['class'=>'form-control']); ?>

</div>
 
<div class="form-group">
	<?php echo Form::label('sku', 'Product sku:', ['class' => 'awesome']); ?>

	<?php echo Form::text('sku', null, ['class'=>'form-control']); ?>

</div>




 <div class="input-group">
   <span class="input-group-btn">
     <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
       <i class="fa fa-picture-o"></i> Choose
     </a>
   </span>
   <input id="thumbnail" class="form-control" type="text" name="img">
 </div>

 <div id="holder">
 	
 </div>

<?php echo Form::submit('Save', ['class'=>'form-control btn btn-primary d-inline-block']);; ?>

<?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/admin/products/_form.blade.php ENDPATH**/ ?>