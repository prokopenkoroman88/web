
<?php  $path='/admin/applications'; 

//+30.4.20
	$product_id=0;
	if(!isset($product)){
		if($applications){
			$product_id=$applications[0]->product->id;
		};
	}
	else{
		$product_id=$product->id;
	};
?>




<table class="admin-table" id="applications-table">
	<tr>
		<th>#</th>
	<?php if(!isset($product)): ?>
		<th>Проект</th>
	<?php endif; ?>
		<th>Модуль</th>
		<th></th>
	</tr>
<?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<tr>
		<td><?php echo e($loop->iteration); ?></td>

	<?php if(!isset($product)): ?>
		<td><a href="/admin/products/<?php echo e($item->product->id); ?>"><?php echo e($item->product->name); ?></a>
		</td>
	<?php endif; ?>		

		<td><?php echo e($item->name); ?></td>
		<td>
			<?php echo e(view('layouts.redact',compact('path','item'))); ?>	
		</td>
	</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<p>

<?php
	if(!isset($product)){
		$product=$applications[0]->product;
	};
?>
<?php echo e(view('layouts.redact',compact('path','product'))); ?>


</p>



		<?php /**PATH D:\STEP\PHP\OSPanel\domains\diplom\resources\views/admin/applications/_list.blade.php ENDPATH**/ ?>